from unittest import TestCase
from server import *

class register:
    def g(self):
        return True

    def p(self, form, username, password, email):
        if form['submit'] == 'back':
            return 'back'
        elif form['submit'] == 'submit':
            conn = user_connect.connect()
            query = conn.execute("select username, password, email, access from users")
            result = query.cursor.fetchall()  # check for repeats

            for i in result:
                if i[0] == username:
                    return 'username'
                elif i[2] == email:
                    return 'email_reg'
            if '@' not in email:
                return 'email_form'

            query = conn.execute(
                "insert into users (username, password, email, access) values ('{}', '{}', '{}', 0);".format(username,
                                                                                                             password,
                                                                                                             email))

        return 'inserted'


class TestRegister(TestCase):
    def setUp(self):
        self.R = register()
        conn = user_connect.connect()
        conn.execute("delete from users where username={};".format("'entirely'"))
        conn.execute("delete from users where username={};".format("'admin '"))
        conn.execute("delete from users where username={};".format("'new'"))
        conn.execute("delete from users where username={};".format("'new2'"))
    def test_g(self):
        self.assertEqual(self.R.g(), True)
    def test_p1(self):
        form = {'submit': 'back'}
        self.assertEqual(self.R.p(form,"does","not","matter"), 'back')
    def test_p2(self):
        form = {'submit': 'submit'}
        self.assertEqual(self.R.p(form,"admin","not","matter"), 'username')
    def test_p3(self):
        form = {'submit': 'submit'}
        self.assertEqual(self.R.p(form,"does","not","admin@pass.info"), 'email_reg')
    def test_p4(self):
        form = {'submit': 'submit'}
        self.assertEqual(self.R.p(form,"entirely","new","user@db.com"), 'inserted')
    def test_p5(self):
        form = {'submit': 'submit'}
        self.assertEqual(self.R.p(form, "admin ", "new", "admin@info.com    "), 'username')
    def test_p6(self):
        form = {'submit': 'submit'}
        self.assertEqual(self.R.p(form, "new", "new", " admin@info.com"), 'email_reg')
    def test_p7(self):
        form = {'submit': 'submit'}
        self.assertEqual(self.R.p(form, "new2", "new", " admin@info"), 'email_form')
