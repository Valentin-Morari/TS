from flask import Flask, request, redirect, render_template, flash
from flask_restful import Resource, Api
from sqlalchemy import create_engine
from flask_jsonpify import jsonify
from flask_httpauth import HTTPBasicAuth
from wtforms import Form

global access, api

db_connect = create_engine('sqlite:///Studenti.db')
user_connect = create_engine('sqlite:///Users.db')
app = Flask(__name__, static_url_path='/home/valentin/Documents/Uni/TS/lab56/python_rest')
api = Api(app)
app.config['SECRET_KEY'] = '7d441f27d441f27567d441f2b6176a'
auth = HTTPBasicAuth()

access = False


def verify_password(username, password):
	global access
	conn = user_connect.connect()
	query = conn.execute("select username, password, access from users")
	result = query.cursor.fetchall()
	if (username, password, 1) in result:
		access = True
		return 'log-in'
	elif (username, password, 0) in result:
		access = False
		return 'activation'
	else:
		access = False
		return False


class Studenti(Resource):
	def get(self):
		global access
		if not access:
			flash("Please log-in first!")
			return redirect('/')
		conn = db_connect.connect() # connect to database
		query = conn.execute("select * from Studenti") # This line performs query and returns json result
		result = {'data': [dict(zip(tuple (query.keys()) ,i)) for i in query.cursor]}
		return jsonify(result)


class Register(Resource):
	@app.route("/register", methods=['GET'])
	def g():
		form = Form(request.form)
		return render_template('register.html', form=form)

	@app.route("/register", methods=['POST'])
	def p():
		form = request.form
		if form['submit']=='back':
			return redirect('/')
		elif form['submit']=='submit':
			conn = user_connect.connect()
			query = conn.execute("select username, password, email, access from users")
			result = query.cursor.fetchall() #check for repeats

			username=request.form['username']
			password=request.form['password']
			email=request.form['email']
			for i in result:
				if i[0] == username:
					flash('Username taken.')
					return render_template('register.html', form=form), 400
				elif i[2] == email:
					flash('Email already registered.')
					return render_template('register.html', form=form), 400
			if '@' not in email:
				flash('E-mail format unacceptable.')
				return render_template('register.html', form=form), 400

			query = conn.execute("insert into users (username, password, email, access) values ('{}', '{}', '{}', 0);".format(username,password,email))
			flash('Registration successful!')
			return render_template('register.html', form=form), 201
		return render_template('register.html', form=form)

class Login_page(Resource):
	global access
	@app.route("/", methods=['GET'])
	def a():
		return render_template('login.html')
	@app.route("/", methods=['POST'])
	def b():
		form = Form(request.form)
		username=request.form['username']
		password=request.form['password']
		verify = verify_password(username,password)
		if not verify:
			flash('Name or password is wrong. ')
			return render_template('login.html', form=form), 400
		elif verify == 'log-in':
			flash('Login successful!')
			return render_template('login.html', form=form), 200
		elif verify == 'activation':
			flash('Your account awaits activation. ')
			return render_template('login.html', form=form), 406


class Add_student(Resource):
	global access
	@app.route("/addstudent", methods=['GET'])
	def get():
		if not access:
			flash("Please log-in first!")
			return redirect("/")
		form = Form(request.form)
		return render_template('addstudent.html', form=form)
	@app.route("/addstudent", methods=['POST'])
	def post():
		form = request.form
		if form['submit']=='back':
			return redirect('/')
		elif form['submit']=='submit':
			conn = db_connect.connect()
			commands = request.form['sql'].split(';')
			if len(commands)>1:
				commands.pop()
			for command in commands:
				if 'insert' not in command.lower():
					flash('"{}" is not an insert instruction!'.format(command))
					return render_template('addstudent.html', form=form), 400
				try:
					query = conn.execute("{}".format(command))
					flash('Student(s) added succesfully.')
					return render_template('addstudent.html', form=form), 201
				except Exception as e:
					flash(e)
					print(e)
					return render_template('addstudent.html', form=form), 500



		return render_template('addstudent.html', form=form)
class Del_student(Resource):
	global access
	@app.route("/delstudent", methods=['GET'])
	def gee():
		if not access:
			flash("Please log-in first!")
			return redirect("/")
		form = Form(request.form)
		return render_template('delstudent.html', form=form)
	@app.route("/delstudent", methods=['POST'])
	def poo():
		form = request.form
		if form['submit']=='back':
			return redirect('/')
		elif form['submit']=='submit':
			conn = db_connect.connect()
			commands = request.form['sql'].split(';')
			if len(commands)>1:
				commands.pop()
			for command in commands:
				if 'delete' not in command.lower():
					flash('"{}" is not a delete instruction!'.format(command))
					return render_template('delstudent.html', form=form), 401
				try:
					query = conn.execute("{}".format(command))
					flash('Student(s) removed succesfully.')
					return render_template('delstudent.html', form=form), 200

				except Exception as e:
					flash(e)
					print (e)
					return render_template('delstudent.html', form=form), 500



		return render_template('delstudent.html', form=form)

api.add_resource(Studenti, '/studenti') # Route_1
api.add_resource(Register, '/register') # Route_2
api.add_resource(Add_student, '/addstudent') # Route_3
api.add_resource(Del_student, '/delstudent') # Route_3
api.add_resource(Login_page, '/')# Route_4


if __name__ == '__main__':
	app.run(port='5001')

