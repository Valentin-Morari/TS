from unittest import TestCase
from server import *

class TestVerify_password(TestCase):
    def test_1(self):
        self.assertEqual(verify_password("asdas","asdasdas"), False)
    def test_2(self):
        self.assertEqual(verify_password("admin", "!@#!JSOD"), False)
    def test_3(self):
        self.assertEqual(verify_password("adpsdlas", "pass"), False)
    def test_4(self):
        self.assertEqual(verify_password("admin", "pass "), False)
    def test_5(self):
        self.assertEqual(verify_password(" admin", "pass"), False)
    def test_6(self):
        self.assertEqual(verify_password("ADMIN", "PASS"), False)
    def test_7(self):
        self.assertEqual(verify_password("admin","pass"), 'log-in')
    def test_8(self):
        self.assertEqual(verify_password("aye","bby"), "activation")
    def test_9(self):
        self.assertEqual(verify_password("admin","pass"), False)
    def test_10(self):
        self.assertEqual(verify_password("admin\n","pass"),False)
    def test_11(self):
        self.assertEqual(verify_password("""admin""","""password"""),False)