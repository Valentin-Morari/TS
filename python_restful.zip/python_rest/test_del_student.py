from unittest import TestCase
from server import *

class Del:

    def get(self, access):
        if not access:
            return False
        return True

    def post(self, form):
        if form['submit']=='back':
            return 'back'
        elif form['submit']=='submit':
            conn = db_connect.connect()
            commands = form['sql'].split(';')
            if len(commands)>1:
                commands.pop()
            for command in commands:
                if 'delete' not in command.lower():
                    return "nodelete"
                try:
                    query = conn.execute("{}".format(command))
                    return "success"

                except Exception as e:
                    print (e)
                    return "failure"


class TestDel_student(TestCase):
    def setUp(self):
        self.A = Del()
    def test_get1(self):
        access = True
        self.assertEqual(self.A.get(access), True)
    def test_get2(self):
        access = False
        self.assertEqual(self.A.get(access), False)
    def test_post1(self):
        form = {'submit':'back'}
        self.assertEqual(self.A.post(form), 'back')
    def test_post2(self):
        form = {'submit':'submit','sql':''}
        self.assertEqual(self.A.post(form), 'nodelete')
    def test_post3(self):
        form = {'submit':'submit','sql':'!@O#KMD@MDLLLLLLLLL delete'}
        self.assertEqual(self.A.post(form), 'failure')
    def test_post4(self):
        form = {'submit':'submit','sql':'delete ASODKQWKWMM'}
        self.assertEqual(self.A.post(form), 'failure')
    def test_post5(self):
        form = {'submit':'submit','sql':'dElEte from ASODKQWKWMM where asodk="12039";'} #table not found
        self.assertEqual(self.A.post(form), 'failure')
    def test_post6(self):
        form = {'submit':'submit','sql':'delete from Studenti where ASKDOsss="123";;;;;;;'}
        self.assertEqual(self.A.post(form), 'failure')
    def test_post7(self):
        form = {'submit':'submit','sql':'delete from Studenti where ID="123";'} #Ar trebui sa informeze ca nu exista asa ID, teoretic
        self.assertEqual(self.A.post(form), 'failure')
    def test_post8(self):
        form = {'submit':'submit','sql':'delete from Studenti where ID="11"'} #Acelasi rezultat de succes ca si in cazul precedent. problematic
        self.assertEqual(self.A.post(form), 'success')