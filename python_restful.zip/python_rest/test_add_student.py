from unittest import TestCase
from server import *

class add:

    def get(self, access):
        if not access:
            return False
        return True

    def post(self, form):
        if form['submit']=='back':
            return 'back'
        elif form['submit']=='submit':
            conn = db_connect.connect()
            commands = form['sql'].split(';')
            if len(commands)>1:
                commands.pop()
            for command in commands:
                if 'insert' not in command.lower():
                    return "noinsert"
                try:
                    query = conn.execute("{}".format(command))
                    return "success"

                except Exception as e:
                    print (e)
                    return "failure"


class TestAdd_student(TestCase):
    def setUp(self):
        self.A = add()
        conn = db_connect.connect()
        conn.execute("delete from studenti where ID={};".format("12"))
        conn.execute("delete from studenti where ID={};".format("13"))
        conn.execute("delete from studenti where ID={};".format("13000000000000000"))
    def test_get1(self):
        access = True
        self.assertEqual(self.A.get(access), True)
    def test_get2(self):
        access = False
        self.assertEqual(self.A.get(access), False)
    def test_post1(self):
        form = {'submit':'back'}
        self.assertEqual(self.A.post(form), 'back')
    def test_post2(self):
        form = {'submit':'submit','sql':''}
        self.assertEqual(self.A.post(form), 'noinsert')
    def test_post3(self):
        form = {'submit':'submit','sql':'!@O#KMD@MDLLLLLLLLL insert'}
        self.assertEqual(self.A.post(form), 'failure')
    def test_post4(self):
        form = {'submit':'submit','sql':'insert ASODKQWKWMM'}
        self.assertEqual(self.A.post(form), 'failure')
    def test_post5(self):
        form = {'submit':'submit','sql':'iNsErT into ASODKQWKWMM (ASDLW) values (ASDPK)'}
        self.assertEqual(self.A.post(form), 'failure')
    def test_post6(self):
        form = {'submit':'submit','sql':'iNsErT into Studenti (ASDLW) values (ASDPK)'}
        self.assertEqual(self.A.post(form), 'failure')
    def test_post7(self):
        form = {'submit':'submit','sql':'iNsErT into Studenti (ID) values (aSD)'}
        self.assertEqual(self.A.post(form), 'failure')
    def test_post8(self):
        form = {'submit':'submit','sql':'iNsErT into Studenti (ID) values (12)'}
        self.assertEqual(self.A.post(form), 'failure')
    def test_post9(self):
        form = {'submit':'submit','sql':'iNsErT into Studenti (ID, Nume, Prenume, Specialitate, Grupa, Universitate) values (12, "ASDL")'}
        self.assertEqual(self.A.post(form), 'failure')
    def test_post10(self):
        form = {'submit':'submit','sql':'''iNsErT into Studenti (ID, Nume, Prenume, Specialitate, Grupa, Universitate) values ("ASDJO", "ASDL" 
        , "ASDL", "ASDL", "AOSID!@#", "ASDL")'''}
        self.assertEqual(self.A.post(form), 'failure') #(sqlite3.IntegrityError) datatype mismatch
    def test_post11(self):
        form = {'submit':'submit','sql':'''iNsErT into Studenti (ID, Nume, Prenume, Specialitate, Grupa, Universitate) values ("12", "ASDL" 
        , "ASDL", "ASDL", "AOSID!@#", "ASDL")'''}
        self.assertEqual(self.A.post(form), 'failure') #Penultima valoare trebuie sa fie constransa la INT, dar .. nu e? BUG!!!
    def test_post12(self):
        form = {'submit':'submit','sql':'''iNsErT into Studenti (ID, Nume, Prenume, Specialitate, Grupa, Universitate) values ("13", "ASDL" 
        , "ASDL", "ASDL", "12", "ASDL")'''}
        self.assertEqual(self.A.post(form), 'success')
    def test_post13(self):
        form = {'submit':'submit','sql':'''iNsErT into Studenti (ID, Nume, Prenume, Specialitate, Grupa, Universitate) 
        values ("1300000000000000000000", "ASDL" 
        , "ASDL", "ASDL", "120000000000000000000000", "ASDL")'''}
        self.assertEqual(self.A.post(form), 'success') #numar posibil prea mare pentru tipul integer la ID
    def test_post14(self):
        form = {'submit':'submit','sql':'''iNsErT into Studenti (ID, Nume, Prenume, Specialitate, Grupa, Universitate) 
        values ("13000000000000000", "ASDL" 
        , "ASDL", "", "120000000000000000000000", "")'''}
        self.assertEqual(self.A.post(form), 'failure') #ultima valoare ar trebui sa activeze regula NOT NULL... ?
    def test_post15(self):
        form = {'submit':'submit','sql':'''iNsErT into Studenti (ID, Nume, Prenume, Specialitate, Grupa, Universitate) 
        values ("13000000000000000", "ASDL" 
        , "ASDL", "", "120----------------00000000000000000000000001111111111111111111111111111111111111111111111111111111111111111111
        111111111111111111111111111111111111111111111111111111111
        11111111111111111111111111111111111111111111111111111111111100000000000000000000000000000000000000000000000000000000000000", "")'''}
        self.assertEqual(self.A.post(form), 'success')