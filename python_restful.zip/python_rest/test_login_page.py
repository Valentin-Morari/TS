from unittest import TestCase

from server import *


class login:
    def a(self):
        return True

    def b(self, username, password):
        verify = verify_password(username, password)
        if not verify:
            return('name/pass')
        elif verify == 'log-in':
            return('login')
        elif verify == 'activation':
            return('activate')


class TestLogin_page(TestCase):
    def setUp(self):
        self.L = login()
    def test_a(self):
        self.assertEqual(self.L.a(), True)
    def test_b1(self):
        self.assertEqual(self.L.b("12ow,0s ~!!~!~ )))))))))))))""""""""#!@", ";DROP TABLE"), 'name/pass')
    def test_b2(self):
        self.assertEqual(self.L.b("aye","bby"), 'activate')
    def test_b3(self):
        self.assertEqual(self.L.b("admin","pass"),'login')

    #Extra tests are redundant, instead see test_verify_password.py
