from unittest import TestCase
from server import *

class studenti():
    def get(self,access):
        if not access:
            return False
        conn = db_connect.connect()  # connect to database
        query = conn.execute("select * from Studenti")  # This line performs query and returns json result
        result = {'data': [dict(zip(tuple(query.keys()), i)) for i in query.cursor]}
        return True


class TestStudenti(TestCase):
    def setUp(self):
        self.stud = studenti()

    def test_get1(self):
        access = True
        self.assertEqual(self.stud.get(access), True)
    def test_get2(self):
        access = False
        self.assertEqual(self.stud.get(access), False)

